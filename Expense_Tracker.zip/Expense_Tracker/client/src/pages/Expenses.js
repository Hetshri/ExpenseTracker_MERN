import React from 'react';

const Expenses = () => {
  const styles = {
    container: {
      maxWidth: 900,
      margin: '24px auto',
      padding: 20,
      borderRadius: 8,
      boxShadow: '0 8px 24px rgba(0,0,0,0.08)',
      background: '#fff',
      fontFamily: "'Segoe UI', Tahoma, Geneva, Verdana, sans-serif"
    },
    header: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      marginBottom: 16
    },
    title: {
      margin: 0,
      fontSize: 20,
      fontWeight: 600,
      color: '#111'
    },
    total: {
      fontSize: 14,
      color: '#555',
      background: '#f5f7fb',
      padding: '6px 10px',
      borderRadius: 6
    },
    addBtn: {
      appearance: 'none',
      border: 'none',
      background: '#007bff',
      color: '#fff',
      padding: '8px 12px',
      borderRadius: 6,
      cursor: 'pointer',
      fontWeight: 600,
      marginLeft: 12
    },
    list: {
      marginTop: 12,
      display: 'grid',
      gap: 10
    },
    item: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center',
      padding: '10px 12px',
      borderRadius: 6,
      border: '1px solid #eee',
      background: '#fafafa'
    },
    itemLeft: { display: 'flex', flexDirection: 'column' },
    itemTitle: { fontSize: 15, fontWeight: 600, marginBottom: 4 },
    itemMeta: { fontSize: 12, color: '#666' },
    amount: { fontSize: 16, fontWeight: 700, color: '#1a9626' },
    empty: { textAlign: 'center', color: '#888', padding: 20 }
  };

  // Example static items — replace with your dynamic data
  const sampleExpenses = [
    { id: 1, title: 'Groceries', category: 'Food', date: '2025-11-18', amount: 850 },
    { id: 2, title: 'Metro Recharge', category: 'Transport', date: '2025-11-19', amount: 120 }
  ];

  const total = sampleExpenses.reduce((s, e) => s + e.amount, 0);

  return (
    <div style={styles.container}>
      <div style={styles.header}>
        <h2 style={styles.title}>Expenses</h2>
        <div style={{ display: 'flex', alignItems: 'center' }}>
          <div style={styles.total}>Total: ₹{total}</div>
          <button style={styles.addBtn} onClick={() => alert('Open add expense form')}>
            + Add
          </button>
        </div>
      </div>

      <div style={styles.list}>
        {sampleExpenses.length === 0 ? (
          <div style={styles.empty}>No expenses yet — add your first expense.</div>
        ) : (
          sampleExpenses.map((exp) => (
            <div key={exp.id} style={styles.item}>
              <div style={styles.itemLeft}>
                <div style={styles.itemTitle}>{exp.title}</div>
                <div style={styles.itemMeta}>{exp.category} • {new Date(exp.date).toLocaleDateString()}</div>
              </div>
              <div style={styles.amount}>₹{exp.amount}</div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};

export default Expenses;