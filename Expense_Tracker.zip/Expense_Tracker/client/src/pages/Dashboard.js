import React, { useEffect, useState } from 'react';
import axios from 'axios';
import ExpenseForm from '../components/ExpenseForm';
import ExpenseItem from '../components/ExpenseItem';

const styles = {
  page: {
    maxWidth: 900,
    margin: '24px auto',
    padding: '20px',
    fontFamily: "'Segoe UI', Roboto, 'Helvetica Neue', Arial",
    background: '#fbfbfc',
    borderRadius: 12,
    boxShadow: '0 6px 18px rgba(24,24,24,0.06)'
  },
  headerRow: {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 18
  },
  title: {
    margin: 0,
    fontSize: 22,
    fontWeight: 600,
    color: '#111827'
  },
  subtitle: {
    margin: 0,
    fontSize: 13,
    color: '#6b7280'
  },
  formWrapper: {
    background: '#ffffff',
    padding: 16,
    borderRadius: 10,
    border: '1px solid #e6e9ee',
    marginBottom: 18
  },
  listWrapper: {
    display: 'grid',
    gap: 12
  },
  empty: {
    padding: 28,
    textAlign: 'center',
    color: '#6b7280',
    background: '#ffffff',
    borderRadius: 10,
    border: '1px dashed #e6e9ee'
  },
  controlsRow: {
    display: 'flex',
    gap: 8,
    alignItems: 'center'
  },
  countBadge: {
    background: '#eef2ff',
    color: '#4338ca',
    fontSize: 12,
    padding: '6px 10px',
    borderRadius: 999
  }
};

export default function Dashboard(){
  const [expenses, setExpenses] = useState([]);
  const [editing, setEditing] = useState(null);

  const fetchExpenses = async () => {
    try {
      const res = await axios.get('/api/expenses');
      setExpenses(res.data);
    } catch (err) {
      console.error(err);
    }
  };

  useEffect(()=> { fetchExpenses() }, []);

  const onCreate = (expense) => setExpenses(prev => [expense, ...prev]);
  const onUpdate = (updated) => setExpenses(prev => prev.map(e => e._id === updated._id ? updated : e));
  const onDelete = (id) => setExpenses(prev => prev.filter(e => e._id !== id));

  return (
    <div style={styles.page}>
      <div style={styles.headerRow}>
        <div>
          <h2 style={styles.title}>Expenses</h2>
          <p style={styles.subtitle}>Track and manage your expenses — add, edit or remove items.</p>
        </div>

        <div style={styles.controlsRow}>
          <div style={styles.countBadge}>{expenses.length} items</div>
        </div>
      </div>

      <div style={styles.formWrapper}>
        <ExpenseForm
          onCreate={onCreate}
          editing={editing}
          setEditing={setEditing}
          onUpdate={onUpdate}
        />
      </div>

      <div style={styles.listWrapper}>
        {expenses.length === 0 ? (
          <div style={styles.empty}>
            No expenses yet — add one using the form above.
          </div>
        ) : (
          expenses.map(exp => (
            <ExpenseItem
              key={exp._id}
              expense={exp}
              onEdit={() => setEditing(exp)}
              onDelete={() => onDelete(exp._id)}
              onUpdated={onUpdate}
            />
          ))
        )}
      </div>
    </div>
  );
}