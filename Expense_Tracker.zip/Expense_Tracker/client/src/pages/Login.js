import React, { useState, useContext } from 'react';
import axios from 'axios';
import { AuthContext } from '../context/AuthContext';
import { useNavigate } from 'react-router-dom';

export default function Login() {
  const [form, setForm] = useState({ email: '', password: '' });
  const { setAuth } = useContext(AuthContext);
  const navigate = useNavigate();

  const submit = async (e) => {
    e.preventDefault();
    try {
      const res = await axios.post('/api/auth/login', form);
      setAuth({ token: res.data.token, user: res.data.user });
      navigate('/');
    } catch (err) {
      alert(err.response?.data?.message || 'Login failed');
    }
  };

  const styles = {
    container: {
      maxWidth: 420,
      margin: '40px auto',
      padding: 24,
      borderRadius: 8,
      boxShadow: '0 6px 18px rgba(0,0,0,0.08)',
      background: '#ffffff',
      fontFamily: "'Segoe UI', Tahoma, Geneva, Verdana, sans-serif"
    },
    title: {
      margin: '0 0 18px 0',
      fontSize: 22,
      fontWeight: 600,
      color: '#111827',
      textAlign: 'center'
    },
    field: {
      display: 'block',
      width: '100%',
      padding: '10px 12px',
      marginBottom: 12,
      borderRadius: 6,
      border: '1px solid #d1d5db',
      fontSize: 15,
      outline: 'none',
      boxSizing: 'border-box'
    },
    fieldFocus: {
      borderColor: '#6b7280',
      boxShadow: '0 0 0 3px rgba(99,102,241,0.08)'
    },
    button: {
      width: '100%',
      padding: '10px 12px',
      borderRadius: 6,
      border: 'none',
      background: '#6366f1',
      color: '#fff',
      fontSize: 16,
      fontWeight: 600,
      cursor: 'pointer'
    },
    smallText: {
      marginTop: 12,
      fontSize: 13,
      color: '#6b7280',
      textAlign: 'center'
    }
  };

  return (
    <form onSubmit={submit} style={styles.container}>
      <h2 style={styles.title}>Login</h2>

      <input
        name="email"
        placeholder="Email"
        value={form.email}
        onChange={e => setForm({ ...form, email: e.target.value })}
        required
        style={styles.field}
      />

      <input
        name="password"
        type="password"
        placeholder="Password"
        value={form.password}
        onChange={e => setForm({ ...form, password: e.target.value })}
        required
        style={styles.field}
      />

      <button type="submit" style={styles.button}>Login</button>

      <div style={styles.smallText}>
        Don't have an account? <a href="/Signup" style={styles.link}>Signup</a>
      </div>
    </form>
  );
}
