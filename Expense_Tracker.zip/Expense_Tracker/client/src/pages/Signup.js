import React, { useState, useContext } from 'react';
import axios from 'axios';
import { AuthContext } from '../context/AuthContext';
import { useNavigate } from 'react-router-dom';

export default function Signup() {
  const [form, setForm] = useState({ name: '', email: '', password: '' });
  const { setAuth } = useContext(AuthContext);
  const navigate = useNavigate();

  const onChange = e => setForm({ ...form, [e.target.name]: e.target.value });

  const submit = async (e) => {
    e.preventDefault();
    try {
      const res = await axios.post('/api/auth/register', form);
      setAuth({ token: res.data.token, user: res.data.user });
      navigate('/');
    } catch (err) {
      alert(err.response?.data?.message || 'Signup failed');
    }
  };

  // Inline style objects
  const styles = {
    container: {
      maxWidth: 420,
      margin: '48px auto',
      padding: 24,
      borderRadius: 12,
      boxShadow: '0 6px 18px rgba(0,0,0,0.08)',
      background: 'linear-gradient(180deg, #ffffff, #fbfbff)'
    },
    title: {
      margin: '0 0 18px 0',
      fontSize: 22,
      fontWeight: 700,
      color: '#1f2d3d',
      textAlign: 'center'
    },
    input: {
      width: '100%',
      padding: '10px 12px',
      margin: '8px 0',
      borderRadius: 8,
      border: '1px solid #e0e6ef',
      outline: 'none',
      fontSize: 15,
      boxSizing: 'border-box'
    },
    button: {
      width: '100%',
      padding: '10px 12px',
      marginTop: 12,
      borderRadius: 8,
      border: 'none',
      background: '#6366f1',
      color: '#fff',
      fontSize: 16,
      fontWeight: 600,
      cursor: 'pointer',
      boxShadow: '0 6px 12px rgba(59,130,246,0.18)'
    },
    smallRow: {
      marginTop: 12,
      fontSize: 13,
      color: '#65748b',
      textAlign: 'center'
    },
    link: {
      color: '#6366f1',
      textDecoration: 'none',
      marginLeft: 6
    }
  };

  return (
    <form onSubmit={submit} style={styles.container}>
      <h2 style={styles.title}>Sign up</h2>

      <input
        name="name"
        placeholder="Name"
        value={form.name}
        onChange={onChange}
        required
        style={styles.input}
      />

      <input
        name="email"
        placeholder="Email"
        value={form.email}
        onChange={onChange}
        required
        style={styles.input}
      />

      <input
        name="password"
        type="password"
        placeholder="Password"
        value={form.password}
        onChange={onChange}
        required
        style={styles.input}
      />

      <button type="submit" style={styles.button}>Signup</button>

      <div style={styles.smallRow}>
        Already have an account?
        <a href="/login" style={styles.link}>Login</a>
      </div>
    </form>
  );
}
