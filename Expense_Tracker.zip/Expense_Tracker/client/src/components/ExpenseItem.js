import React from 'react';
import axios from 'axios';

export default function ExpenseItem({ expense, onEdit, onDelete }) {
  const remove = async () => {
    if (!window.confirm('Delete this expense?')) return;
    try {
      await axios.delete(`/api/expenses/${expense._id}`);
      onDelete();
    } catch (err) {
      alert('Delete failed');
    }
  };

  // Inline style objects
  const styles = {
    container: {
      border: '1px solid #e0e0e0',
      padding: 12,
      marginBottom: 12,
      borderRadius: 8,
      backgroundColor: '#ffffff',
      boxShadow: '0 1px 2px rgba(0,0,0,0.03)',
      transition: 'box-shadow 120ms ease-in-out',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between'
    },
    left: {
      display: 'flex',
      flexDirection: 'column',
      gap: 6,
      flex: 1,
      minWidth: 0
    },
    titleRow: {
      display: 'flex',
      alignItems: 'baseline',
      gap: 8,
      justifyContent: 'space-between'
    },
    title: {
      fontSize: 16,
      fontWeight: 600,
      color: '#111827', // dark
      overflow: 'hidden',
      textOverflow: 'ellipsis',
      whiteSpace: 'nowrap'
    },
    amount: {
      fontSize: 15,
      fontWeight: 700,
      color: '#0f766e' // teal-ish
    },
    meta: {
      fontSize: 12,
      color: '#6b7280' /* gray-500 */,
      marginTop: 4
    },
    actions: {
      display: 'flex',
      gap: 8,
      marginLeft: 12,
      alignSelf: 'flex-start'
    },
    button: {
      padding: '6px 10px',
      borderRadius: 6,
      border: '1px solid transparent',
      background: '#f3f4f6',
      cursor: 'pointer',
      fontSize: 13,
      fontWeight: 600
    },
    editButton: {
      padding: '6px 10px',
      borderRadius: 6,
      border: '1px solid #d1d5db',
      background: '#fff',
      cursor: 'pointer',
      fontSize: 13,
      fontWeight: 600
    },
    deleteButton: {
      padding: '6px 10px',
      borderRadius: 6,
      border: '1px solid #fee2e2',
      background: '#ef4444',
      color: '#fff',
      cursor: 'pointer',
      fontSize: 13,
      fontWeight: 700
    }
  };

  return (
    <div style={styles.container}>
      <div style={styles.left}>
        <div style={styles.titleRow}>
          <div style={styles.title}>{expense.title}</div>
          <div style={styles.amount}>₹{expense.amount}</div>
        </div>
        <div style={styles.meta}>
          {expense.category || 'Uncategorized'} • {new Date(expense.date).toLocaleDateString()}
        </div>
      </div>

      <div style={styles.actions}>
        <button
          type="button"
          onClick={onEdit}
          style={styles.editButton}
          aria-label={`Edit ${expense.title}`}
        >
          Edit
        </button>

        <button
          type="button"
          onClick={remove}
          style={styles.deleteButton}
          aria-label={`Delete ${expense.title}`}
        >
          Delete
        </button>
      </div>
    </div>
  );
}
