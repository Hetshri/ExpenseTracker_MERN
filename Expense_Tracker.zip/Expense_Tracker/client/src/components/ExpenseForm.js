import React, { useEffect, useState } from 'react';
import axios from 'axios';

export default function ExpenseForm({ onCreate, editing, setEditing, onUpdate }) {
  const [form, setForm] = useState({ title:'', amount:'', category:'', date:'', notes:'' });

  useEffect(() => {
    if (editing) {
      setForm({
        title: editing.title,
        amount: editing.amount,
        category: editing.category || '',
        date: editing.date ? new Date(editing.date).toISOString().slice(0,10) : '',
        notes: editing.notes || ''
      });
    } else {
      setForm({ title:'', amount:'', category:'', date:'', notes:'' });
    }
  }, [editing]);

  const submit = async (e) => {
    e.preventDefault();
    try {
      if (editing) {
        const res = await axios.put(`/api/expenses/${editing._id}`, {
          ...form, amount: parseFloat(form.amount)
        });
        onUpdate(res.data);
        setEditing(null);
      } else {
        const res = await axios.post('/api/expenses', {
          ...form, amount: parseFloat(form.amount)
        });
        onCreate(res.data);
      }
      setForm({ title:'', amount:'', category:'', date:'', notes:'' });
    } catch (err) {
      alert(err.response?.data?.message || 'Error saving');
    }
  };

  const inputStyle = {
    padding: "10px",
    margin: "5px 0",
    width: "100%",
    borderRadius: "6px",
    border: "1px solid #ccc",
    fontSize: "15px"
  };

  const buttonStyle = {
    padding: "10px 14px",
    border: "none",
    borderRadius: "6px",
    cursor: "pointer",
    marginRight: "10px",
    fontSize: "15px"
  };

  return (
    <form 
      onSubmit={submit}
      style={{
        marginBottom: 20,
        padding: 20,
        border: "1px solid #ddd",
        borderRadius: 10,
        maxWidth: 500,
        background: "#fafafa",
        boxShadow: "0 2px 6px rgba(0,0,0,0.1)"
      }}
    >
      <input 
        style={inputStyle}
        placeholder="Title" 
        value={form.title} 
        onChange={e=>setForm({...form,title:e.target.value})} 
        required 
      />

      <input 
        style={inputStyle}
        placeholder="Amount" 
        type="number" 
        value={form.amount} 
        onChange={e=>setForm({...form,amount:e.target.value})} 
        required 
      />

      <input 
        style={inputStyle}
        placeholder="Category" 
        value={form.category} 
        onChange={e=>setForm({...form,category:e.target.value})} 
      />

      <input 
        style={inputStyle}
        type="date" 
        value={form.date} 
        onChange={e=>setForm({...form,date:e.target.value})} 
      />

      <input 
        style={inputStyle}
        placeholder="Notes" 
        value={form.notes} 
        onChange={e=>setForm({...form,notes:e.target.value})} 
      />

      <button 
        type="submit"
        style={{
          ...buttonStyle,
          background: editing ? "#0A79DF" : "#28a745",
          color: "#fff"
        }}
      >
        {editing ? 'Update' : 'Add'}
      </button>

      {editing && (
        <button 
          type="button" 
          onClick={() => setEditing(null)}
          style={{ ...buttonStyle, background: "#dc3545", color: "#fff" }}
        >
          Cancel
        </button>
      )}
    </form>
  );
}