// components/PieChart.js
import { Pie } from 'react-chartjs-2';
function PieChart({ expenses }) {
  const data = {
    labels: expenses.map(e => e.category),
    datasets: [{
      data: expenses.map(e => e.amount),
      backgroundColor: ['#FF6384', '#36A2EB', '#FFCE56']
    }]
  };
  return <Pie data={data} />;
}
export default PieChart;