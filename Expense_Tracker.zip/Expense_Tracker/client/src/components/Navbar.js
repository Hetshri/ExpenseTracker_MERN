import React, { useContext } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { AuthContext } from '../context/AuthContext';

export default function Navbar(){
  const { auth, setAuth } = useContext(AuthContext);
  const navigate = useNavigate();

  const logout = () => {
    setAuth({ token: null, user: null });
    navigate('/login');
  };

  // Inline style objects
  const styles = {
    nav: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      padding: '12px 20px',
      borderBottom: '1px solid #e6e6e6',
      boxShadow: '0 1px 3px rgba(0,0,0,0.04)',
      background: '#ffffff',
      position: 'sticky',
      top: 0,
      zIndex: 1000,
      fontFamily: "'Segoe UI', Tahoma, Geneva, Verdana, sans-serif"
    },
    left: {
      display: 'flex',
      alignItems: 'center',
      gap: '16px'
    },
    brand: {
      fontWeight: 700,
      fontSize: '18px',
      color: '#111827',
      textDecoration: 'none'
    },
    link: {
      color: '#374151',
      textDecoration: 'none',
      fontSize: '14px',
      padding: '6px 8px',
      borderRadius: '6px'
    },
    linkHover: {
      background: '#f3f4f6'
    },
    right: {
      display: 'flex',
      alignItems: 'center',
      gap: '12px'
    },
    greeting: {
      color: '#374151',
      fontSize: '14px'
    },
    button: {
      padding: '8px 12px',
      borderRadius: '8px',
      border: '1px solid #e5e7eb',
      background: '#fff',
      cursor: 'pointer',
      fontSize: '14px',
      color: '#111827',
      boxShadow: '0 1px 2px rgba(0,0,0,0.03)'
    },
    primaryButton: {
      padding: '8px 12px',
      borderRadius: '8px',
      border: 'none',
      background: '#2563eb', // blue
      color: '#fff',
      cursor: 'pointer',
      fontSize: '14px'
    }
  };

  return (
    <nav style={styles.nav}>
      <div style={styles.left}>
        <Link to="/" style={styles.brand}>ExpenseTracker</Link>

        {/* simple nav link example */}
        <Link to="/" style={styles.link}>Home</Link>
        <Link to="/about" style={styles.link}>About</Link>
      </div>

      <div style={styles.right}>
        {auth.user ? (
          <>
            <span style={styles.greeting}>Hi, {auth.user.name}</span>
            <button
              onClick={logout}
              style={styles.button}
              aria-label="Logout"
            >
              Logout
            </button>
          </>
        ) : (
          <>
            <Link to="/login" style={styles.link}>Login</Link>
            <Link to="/signup" style={styles.primaryButton}>Signup</Link>
          </>
        )}
      </div>
    </nav>
  );
}